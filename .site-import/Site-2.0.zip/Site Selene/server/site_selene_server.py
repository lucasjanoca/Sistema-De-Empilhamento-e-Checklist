from __future__ import annotations

from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote
from urllib.request import Request, urlopen
from http.cookies import SimpleCookie
import hashlib
import hmac
import json
import mimetypes
import os
import re
import secrets
import socket
import tempfile
import threading
import time
import webbrowser

VERSION = '2.0'
APP_NAME = 'Site Selene'
ROOT = Path(__file__).resolve().parent.parent
PUBLIC_DIR = ROOT / 'public'
PRIVATE_DIR = ROOT / 'private'
DATA_DIR = PRIVATE_DIR / 'data'
CONFIG_DIR = PRIVATE_DIR / 'config'
AUDIT_DIR = PRIVATE_DIR / 'audit'
BACKUP_DIR = PRIVATE_DIR / 'backups'
DATA_FILE = DATA_DIR / 'dados-centrais.json'
USERS_FILE = DATA_DIR / 'usuarios-seguros.json'
AUDIT_FILE = AUDIT_DIR / 'auditoria-segura.ndjson'
AUDIT_KEY_FILE = CONFIG_DIR / 'audit-chain.key'
CONFIG_FILE = CONFIG_DIR / 'configuracao-servidor.json'
PORT = int(os.environ.get('SITE_SELENE_PORT', '8080'))
URL = f'http://localhost:{PORT}/'
LOCK = threading.RLock()
MAX_BODY = 2 * 1024 * 1024
SESSION_COOKIE = 'SITESELENE_SESSION'
PBKDF2_ITERATIONS = 600_000
SESSION_IDLE_DEFAULT = 120
SESSIONS: dict[str, dict] = {}
PALLET_LOCKS: dict[str, dict] = {}
LOGIN_FAILURES: dict[str, list[float]] = {}
LOGIN_BLOCKED_UNTIL: dict[str, float] = {}
LOGIN_WINDOW_SECONDS = 10 * 60
LOGIN_MAX_FAILURES = 5
LOGIN_BLOCK_SECONDS = 15 * 60
ALLOWED_STATIC_EXTENSIONS = {'.html', '.css', '.js', '.png', '.jpg', '.jpeg', '.webp', '.svg', '.ico', '.woff', '.woff2'}
BLOCKED_NAMES = {'.git', '.env', '.svn', '__pycache__', 'private', 'server', 'docs', 'source', 'backup', 'backups', 'dados', 'config'}

DEFAULT_CONFIG = {
    'version': VERSION,
    'sessionIdleMinutes': SESSION_IDLE_DEFAULT,
    'integration': {
        'enabled': False,
        'serverBase': 'http://servidor-interno/api',
        'codGrupo': '',
        'codEmp': '',
        'interval': 10000,
        'routePending': '',
        'routeAttendance': '',
        'writeEnabled': False,
    },
}

# Credenciais temporárias de teste NÃO aparecem em texto no código.
# Os hashes abaixo correspondem às credenciais informadas ao responsável do projeto.
BOOTSTRAP_USERS = [
    {
        'matricula': 'admin', 'nome': 'Técnico de Informática', 'role': 'ti', 'active': True,
        'password': {'salt': 'e14cd34c746e6d5311eb29e0e493c9aa', 'hash': 'b408036bb7e8227adb8bc5788f76ae0116dc2b55ef85ca3603f7260316818d58', 'iterations': PBKDF2_ITERATIONS},
    },
    {
        'matricula': 'enc', 'nome': 'Encarregado', 'role': 'encarregado', 'active': True,
        'password': {'salt': '8244bfc398f11fce8cc1197e806bf2b1', 'hash': '64fd759633e19fb9b2d379500c61fd2ad33cfc986413cbe6277672da98495031', 'iterations': PBKDF2_ITERATIONS},
    },
    {
        'matricula': 'emp', 'nome': 'Empilhador', 'role': 'empilhador', 'active': True,
        'password': {'salt': '10311fbed293e3b0a952d268fa928dbc', 'hash': '24e94b2e137e712e1d87515f7e4c5a27e947047c7be421ab8e42c8765b64d50c', 'iterations': PBKDF2_ITERATIONS},
    },
]

ROLE_PERMISSIONS = {
    'ti': {
        'users:view', 'users:create', 'users:update', 'users:delete', 'audit:view', 'snapshot:read',
        'snapshot:write', 'integration:view', 'integration:update', 'integration:read', 'locks', 'security:view'
    },
    'encarregado': {
        'users:view', 'users:create', 'users:update', 'users:delete', 'audit:view', 'snapshot:read',
        'snapshot:write', 'integration:view', 'integration:read', 'locks'
    },
    'empilhador': {'snapshot:read', 'snapshot:write', 'integration:view', 'integration:read', 'locks'},
}

for d in (PRIVATE_DIR, DATA_DIR, CONFIG_DIR, AUDIT_DIR, BACKUP_DIR):
    d.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(d, 0o700)
    except OSError:
        pass


def secure_chmod(path: Path) -> None:
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def atomic_json_write(path: Path, payload) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='.site-selene-', suffix='.tmp', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
        secure_chmod(path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def deep_copy(value):
    return json.loads(json.dumps(value))


def load_config():
    with LOCK:
        if not CONFIG_FILE.exists():
            atomic_json_write(CONFIG_FILE, DEFAULT_CONFIG)
            return deep_copy(DEFAULT_CONFIG)
        try:
            saved = json.loads(CONFIG_FILE.read_text(encoding='utf-8'))
        except Exception:
            saved = {}
        merged = deep_copy(DEFAULT_CONFIG)
        merged.update({k: v for k, v in saved.items() if k != 'integration'})
        merged['integration'].update(saved.get('integration') or {})
        merged['version'] = VERSION
        # Escrita oficial só será habilitada depois de homologação da integração no backend.
        merged['integration']['writeEnabled'] = False
        return merged


def validate_integration_base(value: str) -> str:
    value = str(value or '').strip().rstrip('/')
    parsed = urlparse(value)
    if parsed.scheme not in {'http', 'https'} or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError('Endereço da integração inválido. Use somente http/https sem credenciais na URL.')
    if len(value) > 300:
        raise ValueError('Endereço da integração muito longo.')
    return value


def save_config(config):
    with LOCK:
        config = deep_copy(config)
        config['version'] = VERSION
        config['sessionIdleMinutes'] = max(15, min(720, int(config.get('sessionIdleMinutes', SESSION_IDLE_DEFAULT))))
        config.setdefault('integration', {})['writeEnabled'] = False
        config['integration']['serverBase'] = validate_integration_base(config['integration'].get('serverBase', DEFAULT_CONFIG['integration']['serverBase']))
        atomic_json_write(CONFIG_FILE, config)


def password_record(password: str):
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, PBKDF2_ITERATIONS)
    return {'salt': salt.hex(), 'hash': digest.hex(), 'iterations': PBKDF2_ITERATIONS}


def password_matches(password: str, record: dict) -> bool:
    try:
        digest = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), bytes.fromhex(record['salt']), int(record.get('iterations', PBKDF2_ITERATIONS)))
        return hmac.compare_digest(digest, bytes.fromhex(record['hash']))
    except Exception:
        return False


def password_policy(password: str) -> tuple[bool, str]:
    if len(password) < 10:
        return False, 'A senha precisa ter pelo menos 10 caracteres.'
    if len(password) > 128:
        return False, 'A senha é muito longa.'
    checks = [re.search(r'[A-Z]', password), re.search(r'[a-z]', password), re.search(r'\d', password), re.search(r'[^A-Za-z0-9]', password)]
    if not all(checks):
        return False, 'Use maiúscula, minúscula, número e símbolo na senha.'
    return True, ''


def ensure_users():
    with LOCK:
        if not USERS_FILE.exists():
            now = int(time.time() * 1000)
            users = []
            for item in BOOTSTRAP_USERS:
                u = deep_copy(item)
                u['createdAt'] = now
                users.append(u)
            atomic_json_write(USERS_FILE, users)
            return users
        try:
            data = json.loads(USERS_FILE.read_text(encoding='utf-8'))
            return data if isinstance(data, list) else []
        except Exception:
            return []


def save_users(users):
    with LOCK:
        atomic_json_write(USERS_FILE, users)


def public_user(u):
    return {
        'matricula': u.get('matricula', ''), 'nome': u.get('nome', ''), 'role': u.get('role', 'empilhador'),
        'active': u.get('active', True), 'createdAt': u.get('createdAt', 0)
    }


def find_user(matricula: str):
    value = str(matricula or '').strip().lower()
    return next((u for u in ensure_users() if str(u.get('matricula', '')).lower() == value), None)


def audit_key() -> bytes:
    with LOCK:
        if not AUDIT_KEY_FILE.exists():
            AUDIT_KEY_FILE.write_bytes(secrets.token_bytes(32))
            secure_chmod(AUDIT_KEY_FILE)
        return AUDIT_KEY_FILE.read_bytes()


def last_audit_hash() -> str:
    if not AUDIT_FILE.exists():
        return 'GENESIS'
    try:
        with AUDIT_FILE.open('rb') as f:
            f.seek(0, os.SEEK_END)
            end = f.tell()
            if end == 0:
                return 'GENESIS'
            pos = end - 1
            while pos > 0:
                f.seek(pos)
                if f.read(1) == b'\n' and pos < end - 1:
                    break
                pos -= 1
            f.seek(pos + (1 if pos else 0))
            line = f.readline().decode('utf-8').strip()
        return json.loads(line).get('chainHash', 'GENESIS') if line else 'GENESIS'
    except Exception:
        return 'GENESIS'


def append_audit(action, details, actor=None, category='sistema', severity='info', extra=None):
    actor = actor or {'nome': 'Sistema', 'matricula': 'sistema', 'role': 'sistema'}
    with LOCK:
        entry = {
            'id': f"srv-{int(time.time() * 1000)}-{secrets.token_hex(4)}",
            'time': int(time.time() * 1000), 'action': str(action)[:180], 'details': str(details)[:2000],
            'category': str(category)[:80], 'actorName': str(actor.get('nome', 'Sistema'))[:160],
            'actorMatricula': str(actor.get('matricula', 'sistema'))[:80], 'actorRole': str(actor.get('role', 'sistema'))[:40],
            'severity': str(severity)[:20], 'source': 'servidor-seguro', 'prevHash': last_audit_hash(),
        }
        if extra:
            entry['extra'] = extra
        canonical = json.dumps(entry, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
        entry['chainHash'] = hmac.new(audit_key(), canonical, hashlib.sha256).hexdigest()
        with AUDIT_FILE.open('a', encoding='utf-8') as f:
            f.write(json.dumps(entry, ensure_ascii=False) + '\n')
            f.flush()
        secure_chmod(AUDIT_FILE)
        return entry


def read_audit(limit=3000):
    if not AUDIT_FILE.exists():
        return []
    try:
        lines = AUDIT_FILE.read_text(encoding='utf-8').splitlines()[-limit:]
    except OSError:
        return []
    out = []
    for line in reversed(lines):
        try:
            out.append(json.loads(line))
        except Exception:
            pass
    return out


def verify_audit_chain() -> tuple[bool, int]:
    if not AUDIT_FILE.exists():
        return True, 0
    key = audit_key()
    prev = 'GENESIS'
    count = 0
    try:
        for line in AUDIT_FILE.read_text(encoding='utf-8').splitlines():
            if not line.strip():
                continue
            e = json.loads(line)
            stored = e.pop('chainHash', '')
            if e.get('prevHash') != prev:
                return False, count
            canonical = json.dumps(e, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
            expected = hmac.new(key, canonical, hashlib.sha256).hexdigest()
            if not hmac.compare_digest(stored, expected):
                return False, count
            prev = stored
            count += 1
        return True, count
    except Exception:
        return False, count


def read_store():
    if not DATA_FILE.exists():
        return {'updatedAt': 0, 'snapshot': None}
    try:
        return json.loads(DATA_FILE.read_text(encoding='utf-8'))
    except Exception:
        return {'updatedAt': 0, 'snapshot': None}


def sanitize_snapshot(snapshot: dict, actor_role: str):
    snap = deep_copy(snapshot)
    snap.pop('users', None)
    data = snap.get('data')
    if not isinstance(data, dict):
        raise ValueError('Formato operacional inválido.')
    # Campos que jamais podem vir do navegador.
    data.pop('users', None)
    data.pop('security', None)
    # Empilhador não controla cadastro de dispositivos nem configurações globais.
    if actor_role == 'empilhador':
        current = (read_store().get('snapshot') or {}).get('data') or {}
        if 'registeredDevices' in current:
            data['registeredDevices'] = deep_copy(current['registeredDevices'])
        else:
            data.pop('registeredDevices', None)
        if 'settings' in current:
            data['settings'] = deep_copy(current['settings'])
        else:
            data.pop('settings', None)
    return snap


def backup_private_state():
    day = time.strftime('%Y-%m-%d')
    path = BACKUP_DIR / f'site-selene-private-{day}.json'
    if not path.exists():
        atomic_json_write(path, {'createdAt': int(time.time() * 1000), 'version': VERSION, 'store': read_store(), 'users': ensure_users(), 'config': load_config()})
    files = sorted(BACKUP_DIR.glob('site-selene-private-*.json'), key=lambda p: p.name)
    for old in files[:-30]:
        try:
            old.unlink()
        except OSError:
            pass


def write_store(snapshot, actor):
    sanitized = sanitize_snapshot(snapshot, actor.get('role', 'empilhador'))
    payload = {'updatedAt': int(time.time() * 1000), 'snapshot': sanitized}
    atomic_json_write(DATA_FILE, payload)
    backup_private_state()
    return payload


def prune():
    now = time.time()
    idle = max(15, int(load_config().get('sessionIdleMinutes', SESSION_IDLE_DEFAULT))) * 60
    for token, s in list(SESSIONS.items()):
        if now - s.get('lastSeen', 0) > idle:
            SESSIONS.pop(token, None)
    for key, item in list(PALLET_LOCKS.items()):
        if item.get('expiresAt', 0) < now:
            PALLET_LOCKS.pop(key, None)
    for key, times in list(LOGIN_FAILURES.items()):
        LOGIN_FAILURES[key] = [t for t in times if now - t < LOGIN_WINDOW_SECONDS]
        if not LOGIN_FAILURES[key]:
            LOGIN_FAILURES.pop(key, None)
    for key, until in list(LOGIN_BLOCKED_UNTIL.items()):
        if until <= now:
            LOGIN_BLOCKED_UNTIL.pop(key, None)


def login_key(ip: str, matricula: str) -> str:
    return hashlib.sha256(f'{ip}|{matricula.lower()}'.encode()).hexdigest()


def login_allowed(ip: str, matricula: str) -> tuple[bool, int]:
    prune()
    key = login_key(ip, matricula)
    until = LOGIN_BLOCKED_UNTIL.get(key, 0)
    if until > time.time():
        return False, max(1, int(until - time.time()))
    return True, 0


def login_failure(ip: str, matricula: str):
    key = login_key(ip, matricula)
    arr = LOGIN_FAILURES.setdefault(key, [])
    arr.append(time.time())
    if len([t for t in arr if time.time() - t < LOGIN_WINDOW_SECONDS]) >= LOGIN_MAX_FAILURES:
        LOGIN_BLOCKED_UNTIL[key] = time.time() + LOGIN_BLOCK_SECONDS
        LOGIN_FAILURES[key] = []


def login_success(ip: str, matricula: str):
    key = login_key(ip, matricula)
    LOGIN_FAILURES.pop(key, None)
    LOGIN_BLOCKED_UNTIL.pop(key, None)


class Handler(BaseHTTPRequestHandler):
    server_version = 'SiteSelene'
    sys_version = ''

    def log_message(self, fmt, *args):
        print(f'[{self.log_date_time_string()}] {fmt % args}')

    def security_headers(self):
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), usb=(), payment=()')
        self.send_header('Cross-Origin-Opener-Policy', 'same-origin')
        self.send_header('Cross-Origin-Resource-Policy', 'same-origin')
        self.send_header('X-Permitted-Cross-Domain-Policies', 'none')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'; manifest-src 'self'")

    def end_headers(self):
        self.security_headers()
        super().end_headers()

    def send_json(self, status, payload, cookies=None):
        body = json.dumps(payload, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        for c in cookies or []:
            self.send_header('Set-Cookie', c)
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(body)

    def send_page(self, status: int, title: str, message: str):
        body = f'''<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{status} — Site Selene</title><style>body{{margin:0;background:#071a17;color:#eafff9;font-family:Arial,sans-serif;display:grid;place-items:center;min-height:100vh}}main{{max-width:650px;padding:42px;border:1px solid #1f6f5c;border-radius:24px;background:#0c2923;box-shadow:0 24px 80px #0008}}b{{font-size:64px;color:#59e2b4}}h1{{margin:.2em 0}}p{{color:#b9d7cf;line-height:1.6}}a{{color:#59e2b4}}</style></head><body><main><b>{status}</b><h1>{title}</h1><p>{message}</p><a href="/">Voltar ao Site Selene</a></main></body></html>'''.encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(body)

    def body(self):
        ctype = self.headers.get('Content-Type', '')
        if 'application/json' not in ctype:
            raise ValueError('Conteúdo inválido.')
        try:
            n = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            n = 0
        if n <= 0 or n > MAX_BODY:
            raise ValueError('Tamanho de dados inválido.')
        return json.loads(self.rfile.read(n).decode('utf-8'))

    def cookie(self, token: str, max_age=None):
        secure = self.headers.get('X-Forwarded-Proto', '').lower() == 'https'
        parts = [f'{SESSION_COOKIE}={token}', 'Path=/', 'HttpOnly', 'SameSite=Strict']
        if secure:
            parts.append('Secure')
        if max_age is not None:
            parts.append(f'Max-Age={max_age}')
        return '; '.join(parts)

    def session(self, required=True):
        prune()
        c = SimpleCookie(self.headers.get('Cookie', ''))
        token = c.get(SESSION_COOKIE).value if c.get(SESSION_COOKIE) else ''
        s = SESSIONS.get(token)
        if s:
            user = find_user(s.get('matricula', ''))
            ua = hashlib.sha256(self.headers.get('User-Agent', '').encode()).hexdigest()
            if not user or user.get('active') is False or not hmac.compare_digest(ua, s.get('uaHash', '')):
                SESSIONS.pop(token, None)
                s = None
            else:
                s['lastSeen'] = time.time()
                s['user'] = public_user(user)
        if required and not s:
            self.send_json(401, {'ok': False, 'message': 'Sessão inválida ou expirada.'})
            return None
        return s

    def perm(self, permission):
        s = self.session(True)
        if not s:
            return None
        if permission not in ROLE_PERMISSIONS.get(s['user'].get('role'), set()):
            append_audit('Acesso negado pelo servidor', f'Permissão bloqueada: {permission}.', s['user'], 'seguranca', 'warning', {'ip': self.client_address[0]})
            self.send_json(403, {'ok': False, 'message': 'Seu perfil não possui permissão para esta ação.'})
            return None
        return s

    def csrf(self, s):
        token = self.headers.get('X-CSRF-Token', '')
        if not token or not hmac.compare_digest(token, s.get('csrf', '')):
            append_audit('Bloqueio CSRF', 'Alteração sem token válido.', s['user'], 'seguranca', 'warning', {'ip': self.client_address[0]})
            self.send_json(403, {'ok': False, 'message': 'Validação de segurança da sessão falhou.'})
            return False
        return True

    def static_path(self, raw_path: str):
        path = unquote(raw_path.split('?', 1)[0])
        if path == '/':
            path = '/index.html'
        parts = [p for p in Path(path.lstrip('/')).parts if p not in ('', '.')]
        if any(p.startswith('.') or p.lower() in BLOCKED_NAMES for p in parts):
            return None, 403
        candidate = (PUBLIC_DIR / Path(*parts)).resolve()
        try:
            candidate.relative_to(PUBLIC_DIR.resolve())
        except ValueError:
            return None, 403
        if not candidate.is_file():
            return None, 404
        if candidate.suffix.lower() not in ALLOWED_STATIC_EXTENSIONS:
            return None, 403
        return candidate, 200

    def serve_static(self, path):
        file, status = self.static_path(path)
        if status == 403:
            self.send_page(403, 'Acesso restrito', 'Este recurso pertence à área privada do sistema e não pode ser acessado pelo navegador.')
            return
        if status == 404:
            self.send_page(404, 'Recurso não encontrado', 'O endereço solicitado não está disponível na área pública do sistema.')
            return
        data = file.read_bytes()
        content_type = mimetypes.guess_type(file.name)[0] or 'application/octet-stream'
        self.send_response(200)
        self.send_header('Content-Type', content_type + ('; charset=utf-8' if content_type.startswith(('text/', 'application/javascript')) else ''))
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(data)

    def do_HEAD(self):
        parsed = urlparse(self.path)
        if parsed.path.startswith('/api/'):
            self.send_json(405, {'ok': False, 'message': 'Método não permitido.'})
        else:
            self.serve_static(parsed.path)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path.rstrip('/')
        if not path.startswith('/api/site-selene'):
            self.serve_static(parsed.path)
            return
        if path == '/api/site-selene/status':
            self.send_json(200, {'ok': True, 'version': VERSION, 'security': 'enterprise-server', 'publicRootOnly': True})
            return
        if path == '/api/site-selene/auth/me':
            s = self.session(True)
            if s:
                self.send_json(200, {'ok': True, 'user': s['user'], 'csrfToken': s['csrf'], 'sessionIdleMinutes': load_config().get('sessionIdleMinutes', SESSION_IDLE_DEFAULT)})
            return
        if path == '/api/site-selene/snapshot':
            if self.perm('snapshot:read'):
                self.send_json(200, read_store())
            return
        if path == '/api/site-selene/users':
            if self.perm('users:view'):
                self.send_json(200, {'ok': True, 'users': [public_user(u) for u in ensure_users()]})
            return
        if path == '/api/site-selene/audit-secure':
            if self.perm('audit:view'):
                limit = min(5000, max(1, int((parse_qs(parsed.query).get('limit') or ['3000'])[0])))
                self.send_json(200, {'ok': True, 'events': read_audit(limit)})
            return
        if path == '/api/site-selene/security/status':
            s = self.perm('security:view')
            if s:
                intact, audit_count = verify_audit_chain()
                self.send_json(200, {
                    'ok': True, 'mode': 'servidor-enterprise', 'passwordStorage': 'PBKDF2-HMAC-SHA256',
                    'pbkdf2Iterations': PBKDF2_ITERATIONS, 'sessionCookie': 'HttpOnly + SameSite=Strict',
                    'csrf': True, 'secureAudit': True, 'auditIntegrity': intact, 'auditEvents': audit_count,
                    'securityHeaders': True, 'staticIsolation': True, 'directoryListing': False,
                    'rateLimit': True, 'automaticBackups': True, 'sessionIdleMinutes': load_config().get('sessionIdleMinutes', SESSION_IDLE_DEFAULT),
                    'role': s['user']['role']
                })
            return
        if path == '/api/site-selene/integration/config':
            s = self.perm('integration:view')
            if not s:
                return
            cfg = load_config()['integration'].copy()
            cfg['writeEnabled'] = False
            if s['user']['role'] != 'ti':
                cfg.pop('serverBase', None)
                cfg.pop('codGrupo', None)
                cfg.pop('codEmp', None)
                cfg.pop('routePending', None)
                cfg.pop('routeAttendance', None)
            self.send_json(200, {'ok': True, 'config': cfg})
            return
        if path == '/api/site-selene/integration/read':
            s = self.perm('integration:read')
            if not s:
                return
            route = (parse_qs(parsed.query).get('route') or [''])[0].strip()
            cfg = load_config()['integration']
            allowed_routes = {str(cfg.get('routePending', '')).strip(), str(cfg.get('routeAttendance', '')).strip()} - {''}
            if not route or route not in allowed_routes:
                self.send_json(400, {'ok': False, 'message': 'Rota de leitura não configurada ou não permitida.'})
                return
            base = str(cfg.get('serverBase', '')).rstrip('/')
            target = f"{base}/{route.lstrip('/')}?codGrupo={cfg.get('codGrupo', '')}&codEmp={cfg.get('codEmp', '')}"
            try:
                req = Request(target, headers={'Accept': 'application/json', 'User-Agent': f'SiteSelene/{VERSION}'})
                with urlopen(req, timeout=5) as r:
                    raw = r.read(MAX_BODY + 1)
                    if len(raw) > MAX_BODY:
                        raise ValueError('Resposta maior que o limite permitido.')
                    payload = json.loads(raw.decode('utf-8'))
                self.send_json(200, {'ok': True, 'data': payload})
            except Exception as e:
                append_audit('Falha de leitura Selene', f'{route}: {type(e).__name__}: {e}', s['user'], 'integracao', 'warning')
                self.send_json(502, {'ok': False, 'message': 'A API da Selene não respondeu. Consulte o Painel TI.'})
            return
        self.send_json(404, {'ok': False, 'message': 'Rota não encontrada.'})

    def do_POST(self):
        path = urlparse(self.path).path.rstrip('/')
        if path == '/api/site-selene/auth/login':
            try:
                p = self.body()
                matricula = str(p.get('matricula', '')).strip()[:80]
                senha = str(p.get('senha', ''))
            except Exception as e:
                self.send_json(400, {'ok': False, 'message': str(e)})
                return
            ip = self.client_address[0]
            allowed, wait = login_allowed(ip, matricula)
            if not allowed:
                append_audit('Login temporariamente bloqueado', 'Excesso de tentativas de acesso.', {'nome': 'Proteção de acesso', 'matricula': matricula or 'não informada', 'role': 'sistema'}, 'seguranca', 'warning', {'ip': ip})
                self.send_json(429, {'ok': False, 'message': f'Muitas tentativas. Tente novamente em aproximadamente {max(1, wait // 60)} minuto(s).'})
                return
            user = find_user(matricula)
            if not user or user.get('active') is False or not password_matches(senha, user.get('password') or {}):
                login_failure(ip, matricula)
                time.sleep(0.25)
                append_audit('Login negado', 'Matrícula/senha incorreta ou usuário bloqueado.', public_user(user) if user else {'nome': 'Tentativa de login', 'matricula': matricula or 'não informada', 'role': 'sistema'}, 'acesso', 'warning', {'ip': ip})
                self.send_json(401, {'ok': False, 'message': 'Senha ou matrícula incorreta.'})
                return
            login_success(ip, matricula)
            token = secrets.token_urlsafe(48)
            csrf = secrets.token_urlsafe(32)
            ua_hash = hashlib.sha256(self.headers.get('User-Agent', '').encode()).hexdigest()
            SESSIONS[token] = {'matricula': user['matricula'], 'csrf': csrf, 'createdAt': time.time(), 'lastSeen': time.time(), 'user': public_user(user), 'uaHash': ua_hash}
            append_audit('Login realizado', f"Acesso pelo perfil {user.get('role')}", public_user(user), 'acesso', extra={'ip': ip})
            self.send_json(200, {'ok': True, 'user': public_user(user), 'csrfToken': csrf, 'sessionIdleMinutes': load_config().get('sessionIdleMinutes', SESSION_IDLE_DEFAULT)}, [self.cookie(token)])
            return
        if path == '/api/site-selene/auth/logout':
            s = self.session(False)
            if s and not self.csrf(s):
                return
            c = SimpleCookie(self.headers.get('Cookie', ''))
            if s:
                append_audit('Logout realizado', 'Sessão encerrada.', s['user'], 'acesso')
            if c.get(SESSION_COOKIE):
                SESSIONS.pop(c[SESSION_COOKIE].value, None)
            self.send_json(200, {'ok': True}, [self.cookie('', 0)])
            return
        if path == '/api/site-selene/users':
            s = self.perm('users:create')
            if not s or not self.csrf(s):
                return
            try:
                p = self.body()
            except Exception as e:
                self.send_json(400, {'ok': False, 'message': str(e)})
                return
            nome = str(p.get('nome', '')).strip()[:160]
            matricula = str(p.get('matricula', '')).strip()[:80]
            senha = str(p.get('senha', ''))
            role = str(p.get('role', 'empilhador'))
            ok, msg = password_policy(senha)
            if not nome or not matricula or not ok or role not in {'empilhador', 'encarregado', 'ti'}:
                self.send_json(400, {'ok': False, 'message': msg or 'Dados do usuário inválidos.'})
                return
            if role == 'ti' and s['user']['role'] != 'ti':
                self.send_json(403, {'ok': False, 'message': 'Somente TI pode criar TI.'})
                return
            users = ensure_users()
            if any(str(u.get('matricula', '')).lower() == matricula.lower() for u in users):
                self.send_json(409, {'ok': False, 'message': 'Já existe um usuário com essa matrícula.'})
                return
            rec = {'matricula': matricula, 'nome': nome, 'role': role, 'active': True, 'createdAt': int(time.time() * 1000), 'password': password_record(senha)}
            users.append(rec)
            save_users(users)
            backup_private_state()
            append_audit('Usuário criado', f'{nome} · {matricula} · {role}.', s['user'], 'usuario')
            self.send_json(201, {'ok': True, 'user': public_user(rec)})
            return
        if path == '/api/site-selene/audit-secure':
            s = self.session(True)
            if not s or not self.csrf(s):
                return
            try:
                p = self.body()
            except Exception as e:
                self.send_json(400, {'ok': False, 'message': str(e)})
                return
            self.send_json(201, {'ok': True, 'event': append_audit(p.get('action', 'Evento'), p.get('details', ''), s['user'], p.get('category', 'sistema'), p.get('severity', 'info'))})
            return
        if path in {'/api/site-selene/locks/acquire', '/api/site-selene/locks/release'}:
            s = self.perm('locks')
            if not s or not self.csrf(s):
                return
            try:
                p = self.body()
            except Exception as e:
                self.send_json(400, {'ok': False, 'message': str(e)})
                return
            key = str(p.get('address') or p.get('palletId') or '').strip().upper()[:160]
            if not key:
                self.send_json(400, {'ok': False, 'message': 'Palete inválido.'})
                return
            prune()
            ex = PALLET_LOCKS.get(key)
            if path.endswith('acquire'):
                if ex and ex.get('owner') != s['user']['matricula'] and ex.get('expiresAt', 0) > time.time():
                    append_audit('Conflito de palete bloqueado', f'{key} já estava em movimentação.', s['user'], 'seguranca', 'warning', {'lockedBy': ex.get('owner')})
                    self.send_json(409, {'ok': False, 'message': 'Palete já está sendo movimentado por outro operador.', 'lockedBy': ex.get('ownerName', 'Outro operador')})
                    return
                PALLET_LOCKS[key] = {'owner': s['user']['matricula'], 'ownerName': s['user']['nome'], 'expiresAt': time.time() + 35, 'direction': str(p.get('direction', ''))[:30]}
                self.send_json(200, {'ok': True, 'expiresIn': 35})
                return
            if ex and (ex.get('owner') == s['user']['matricula'] or s['user']['role'] in {'ti', 'encarregado'}):
                PALLET_LOCKS.pop(key, None)
            self.send_json(200, {'ok': True})
            return
        self.send_json(404, {'ok': False, 'message': 'Rota não encontrada.'})

    def do_PUT(self):
        path = urlparse(self.path).path.rstrip('/')
        if path == '/api/site-selene/snapshot':
            s = self.perm('snapshot:write')
            if not s or not self.csrf(s):
                return
            try:
                snap = self.body()
                if not isinstance(snap, dict) or 'data' not in snap:
                    raise ValueError('Formato inválido.')
                saved = write_store(snap, s['user'])
            except Exception as e:
                self.send_json(400, {'ok': False, 'message': str(e)})
                return
            self.send_json(200, {'ok': True, 'updatedAt': saved['updatedAt']})
            return
        if path == '/api/site-selene/integration/config':
            s = self.perm('integration:update')
            if not s or not self.csrf(s):
                return
            if s['user']['role'] != 'ti':
                self.send_json(403, {'ok': False, 'message': 'Somente TI pode alterar a integração.'})
                return
            try:
                p = self.body()
                cfg = load_config()
                cur = cfg['integration']
                cur.update({
                    'enabled': bool(p.get('enabled', cur.get('enabled', True))),
                    'serverBase': validate_integration_base(p.get('serverBase', cur.get('serverBase', ''))),
                    'codGrupo': str(p.get('codGrupo', cur.get('codGrupo', ''))).strip()[:60] or '',
                    'codEmp': str(p.get('codEmp', cur.get('codEmp', ''))).strip()[:60] or '',
                    'interval': max(5000, min(300000, int(p.get('interval', cur.get('interval', 10000))))),
                    'routePending': str(p.get('routePending', cur.get('routePending', ''))).strip()[:240],
                    'routeAttendance': str(p.get('routeAttendance', cur.get('routeAttendance', ''))).strip()[:240],
                    'writeEnabled': False,
                })
                save_config(cfg)
                backup_private_state()
            except Exception as e:
                self.send_json(400, {'ok': False, 'message': str(e)})
                return
            append_audit('Configuração de integração alterada', f"Servidor {cur['serverBase']} · grupo {cur['codGrupo']} · empresa {cur['codEmp']}.", s['user'], 'integracao')
            self.send_json(200, {'ok': True, 'config': cur})
            return
        self.send_json(404, {'ok': False, 'message': 'Rota não encontrada.'})

    def do_PATCH(self):
        path = urlparse(self.path).path.rstrip('/')
        prefix = '/api/site-selene/users/'
        if not path.startswith(prefix):
            self.send_json(404, {'ok': False, 'message': 'Rota não encontrada.'})
            return
        s = self.perm('users:update')
        if not s or not self.csrf(s):
            return
        matricula = unquote(path[len(prefix):])[:80]
        try:
            p = self.body()
        except Exception as e:
            self.send_json(400, {'ok': False, 'message': str(e)})
            return
        users = ensure_users()
        user = next((x for x in users if str(x.get('matricula', '')).lower() == matricula.lower()), None)
        if not user:
            self.send_json(404, {'ok': False, 'message': 'Usuário não encontrado.'})
            return
        actor = s['user']
        action = str(p.get('action', ''))
        if user.get('role') == 'ti' and actor.get('role') != 'ti':
            self.send_json(403, {'ok': False, 'message': 'Somente TI pode alterar conta TI.'})
            return
        if action == 'password':
            senha = str(p.get('senha', ''))
            ok, msg = password_policy(senha)
            if not ok:
                self.send_json(400, {'ok': False, 'message': msg})
                return
            user['password'] = password_record(senha)
            detail = f'Senha redefinida para {user.get("nome", matricula)}.'
        elif action == 'role':
            role = str(p.get('role', ''))
            if role not in {'empilhador', 'encarregado', 'ti'}:
                self.send_json(400, {'ok': False, 'message': 'Perfil inválido.'})
                return
            if role == 'ti' and actor.get('role') != 'ti':
                self.send_json(403, {'ok': False, 'message': 'Somente TI pode criar TI.'})
                return
            old = user.get('role')
            user['role'] = role
            detail = f'Perfil {old} → {role} para {matricula}.'
        elif action == 'active':
            if user.get('role') == 'ti' and actor.get('role') != 'ti':
                self.send_json(403, {'ok': False, 'message': 'Somente TI pode bloquear ou desbloquear uma conta TI.'})
                return
            user['active'] = bool(p.get('active'))
            detail = f"Usuário {matricula} {'desbloqueado' if user['active'] else 'bloqueado'}."
        else:
            self.send_json(400, {'ok': False, 'message': 'Ação inválida.'})
            return
        save_users(users)
        backup_private_state()
        append_audit('Usuário alterado', detail, actor, 'usuario')
        self.send_json(200, {'ok': True, 'user': public_user(user)})

    def do_DELETE(self):
        path = urlparse(self.path).path.rstrip('/')
        prefix = '/api/site-selene/users/'
        if not path.startswith(prefix):
            self.send_json(404, {'ok': False, 'message': 'Rota não encontrada.'})
            return
        s = self.perm('users:delete')
        if not s or not self.csrf(s):
            return
        matricula = unquote(path[len(prefix):])[:80]
        users = ensure_users()
        idx = next((i for i, u in enumerate(users) if str(u.get('matricula', '')).lower() == matricula.lower()), -1)
        if idx < 0:
            self.send_json(404, {'ok': False, 'message': 'Usuário não encontrado.'})
            return
        target = users[idx]
        actor = s['user']
        if target.get('role') == 'ti' and actor.get('role') != 'ti':
            self.send_json(403, {'ok': False, 'message': 'Somente TI pode excluir uma conta TI.'})
            return
        if target.get('role') == 'ti':
            active_ti = [u for u in users if u.get('role') == 'ti' and u.get('active') is not False]
            if len(active_ti) <= 1:
                self.send_json(409, {'ok': False, 'message': 'Crie outra conta TI antes de excluir a última conta TI ativa.'})
                return
        users.pop(idx)
        save_users(users)
        backup_private_state()
        append_audit('Usuário excluído', f"{target.get('nome')} · {matricula}.", actor, 'usuario', 'warning')
        self.send_json(200, {'ok': True, 'deletedSelf': actor.get('matricula') == target.get('matricula')})

    def do_OPTIONS(self):
        self.send_json(405, {'ok': False, 'message': 'Método não permitido.'})


def local_ip():
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(('10.255.255.255', 1))
            return s.getsockname()[0]
    except OSError:
        return 'IP-DO-NOTEBOOK'


def main():
    ensure_users()
    load_config()
    audit_key()
    backup_private_state()
    if os.environ.get('SITE_SELENE_NO_BROWSER') != '1':
        threading.Timer(1.0, lambda: webbrowser.open(URL)).start()
    print('=' * 76)
    print('SITE SELENE 2.0 — FINAL / TI READY')
    print(f'Notebook: {URL}')
    print(f'Rede: http://{local_ip()}:{PORT}/')
    print('Área pública isolada | Privado bloqueado | PBKDF2 | CSRF | Rate limit')
    print('Auditoria encadeada | Backup privado | Trava de palete | Sistema oficial via servidor')
    print('=' * 76)
    try:
        ThreadingHTTPServer(('0.0.0.0', PORT), Handler).serve_forever()
    except KeyboardInterrupt:
        pass
    except OSError as e:
        print(f'Não foi possível iniciar: {e}')
        input('ENTER para fechar...')


if __name__ == '__main__':
    main()
