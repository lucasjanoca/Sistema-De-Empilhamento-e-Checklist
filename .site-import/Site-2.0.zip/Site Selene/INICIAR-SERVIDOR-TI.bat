@echo off
setlocal
cd /d "%~dp0"
echo ===============================================================
echo SITE SELENE 2.0 - SERVIDOR TI
echo ===============================================================
echo O servidor ficara aberto nesta janela para exibir os logs.
echo Fechar esta janela encerra o servidor.
echo.
where py >nul 2>nul
if not errorlevel 1 (
  py server\site_selene_server.py
  goto fim
)
where python >nul 2>nul
if not errorlevel 1 (
  python server\site_selene_server.py
  goto fim
)
echo Python 3 nao foi encontrado. Consulte INSTALACAO-TI.txt.
:fim
pause
endlocal
